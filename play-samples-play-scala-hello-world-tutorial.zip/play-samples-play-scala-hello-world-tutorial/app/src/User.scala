package src

class User(val name: String, val age: Int) {
  def get_name():String = this.name

  def get_age():Int =  this.age

  override def toString: String =
    this.name + " has " + this.age + " years old"

  /*object User {
    implicit val reads = Json.reads[User]
    implicit val writes = Json.writes[User]
  }*/
}
