package controllers

import com.typesafe.sslconfig.ssl.FakeChainedKeyStore.User
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import src.{MongoDB, User}
/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  /**
   * Create an Action to render an HTML page.
   *
   * The configuration in the `routes` file means that this method
   * will be called when the application receives a `GET` request with
   * a path of `/`.
   */
  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }

  def explore() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.explore())
  }

  def tutorial() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.tutorial())
  }

  def trial() = Action {
    println("oi")
    implicit request: Request[AnyContent] =>
      Ok(request.body.toString())
  }

  def getUser(name: String) = Action {
    val mongo = new MongoDB("test")
    val response = mongo.getUserByName(name)
    implicit request: Request[AnyContent] =>
      Ok(Json.toJson(response))
  }

  def updateUser(name: String) = Action {
    println("oi")
    implicit request: Request[AnyContent] =>
      Ok(request.body.toString())
  }

  def createUser() = Action {
    implicit request: Request[AnyContent] =>
      //getUserFromRequest(request)
      Ok(request.body.toString)
  }

  def deleteUser(name: String) = Action {
    println("oi")
    implicit request: Request[AnyContent] =>
      Ok(request.body.toString())
  }
  implicit val reads = Json.reads[User]
  implicit val writes = Json.writes[User]
}