package src

object mongo {
    def main(args: Array[String]): Unit = {
      val user:User = new User("ullayne", 10)
      val mongo = new MongoDB("test")
      mongo.insertUser(user)
      var result = mongo.getUserByName("ullayne")
      println(result)
    }
}