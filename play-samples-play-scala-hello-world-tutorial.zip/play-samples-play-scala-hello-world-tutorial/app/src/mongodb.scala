package src

import org.bson.codecs.configuration.CodecRegistries.{fromProviders, fromRegistries}
import org.mongodb.scala.MongoClient.DEFAULT_CODEC_REGISTRY
import org.mongodb.scala.bson.codecs.Macros._
import org.mongodb.scala.model.Filters._
import org.mongodb.scala.{MongoClient, MongoCollection, MongoDatabase}
import src.Helpers._

class MongoDB(val name: String) {
  val collection:MongoCollection[User] = getCollection(name)

  def getDatabase(dbName: String) = {
    val codecRegistry = fromRegistries(fromProviders(classOf[User]), DEFAULT_CODEC_REGISTRY)

    val mongoClient: MongoClient = MongoClient()

    val database: MongoDatabase = mongoClient.getDatabase(dbName).withCodecRegistry(codecRegistry)
    database
  }

  def getCollection(dbName: String):MongoCollection[User] = getDatabase(this.name).getCollection(this.name)

  def getUserByName(name: String): Any = {
    this.collection.find(equal("name", name)).results()
  }

  def insertUser(user: User) = {
    this.collection.insertOne(user)
  }

  def deleteUser(userName: String) = {
    this.collection.deleteOne(equal("name", userName)).printHeadResult("Delete Result: ")
  }
}
